
    public enum preparation {  
        ReadingAll,
        ReadingSome,
        ReadingNone
    }
