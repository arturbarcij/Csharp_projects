using System;
using System.Collections.Generic;

public class Tank {
    private int ammunition {get; set;}
    public string name {get; private set;}
    public int life {get; private set;}
    private int fuel {get; set;}

    private Random rand = new Random();


    public Tank (string Name, int Ammunition, int Fuel, int Life ) {
        name = Name;
        ammunition = Ammunition;
        fuel = Fuel;
        life = Life;
        Console.WriteLine("Creating TANK WITH ATTRIBUTES");
        Console.WriteLine("Name: {0}, Ammo: {1}, Fuel: {2}, Life: {3}", 
        Name, Ammunition, Fuel, Life);
    }

     public virtual bool hasLost() {
        if (life <= 0) {
            
            return true;
        }
        else {
            return false;
        }
    }
      public virtual int UpdateLife(int amount) {
        int generator = rand.Next(101);
        if (life > generator) {
            return life;
        }
        else {
            Console.WriteLine("Tank was damaged by amount {1}", amount);
            life -= amount;
            return life;
        }
    }

    public void ShootAt(Tank t0, Tank t1) {
        Console.WriteLine("TANK {0} IS SHOOTING ON {1}", t0.name, t1.name);
        
        if (t1.hasLost()) {
            Console.WriteLine("T0 won");
            
        }
        else {
            Console.WriteLine("T1 won");
            
        }
        
    }

    public Tank Execution(Tank tank){
        if (tank.hasLost()) {
            Console.WriteLine("Tank {0} has been executed.", tank.name);
            return tank;
        }
        else {
            Console.WriteLine("Tank {0} is on the battlefield.", tank.name);
            return tank;
        }
        
    }

        public virtual void getExperience() {
        life += 1;
        ammunition += 2;

        if (ammunition == 0) {
            ammunition += 20;
        }
        else {
            ammunition += 10;
        }
    }

}