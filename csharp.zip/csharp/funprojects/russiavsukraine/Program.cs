﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;

class Program {
    public static void Main() {
    List <Tank> listOfTanks = new List<Tank> ();

    Tank tank0;
    Tank tank1;
    Tank tank2;
    Tank tank3;
    Tank tank4;
    Tank tank5;
    Tank tank6;
    Tank tank7;
    Tank tank8;
    Tank tank9;

    for (int i = 0; i < 9; i++) {
        tank0 = new Tank("tank0",30,20,100);
        tank1 = new Tank("tank1",30,20,100);
        tank2 = new Tank("tank2",30,20,100);
        tank3 = new Tank("tank3",30,20,100);
        tank4 = new Tank("tank4",30,20,100);
        tank5 = new Tank("tank5",30,20,100);
        tank6 = new Tank("tank6",30,20,100);
        tank7 = new Tank("tank7",30,20,100);
        tank8 = new Tank("tank8",30,20,100);
        tank9 = new Tank("tank9",30,20,100);
        
        listOfTanks.Add(tank0);    
        listOfTanks.Add(tank1);
    }

    Console.WriteLine("----------------------------");
    Console.WriteLine("WAR BEGINS");
    Console.WriteLine("----------------------------");

    Console.WriteLine(listOfTanks);
    Console.WriteLine("----------------------------");

    Console.WriteLine("----------------------------");
    Console.WriteLine("War campaign starts!");
    Console.WriteLine("----------------------------");

    Console.WriteLine(listOfTanks[0].life);
    Console.WriteLine(listOfTanks[1].life);
    Console.WriteLine(listOfTanks[2].life);

    listOfTanks[0].ShootAt(listOfTanks[0], listOfTanks[1]);
    listOfTanks[1].ShootAt(listOfTanks[1], listOfTanks[0]);
    
    listOfTanks[0].UpdateLife(10);
    listOfTanks[1].UpdateLife(10);
    
    listOfTanks[0].Execution(listOfTanks[0]);

    Console.WriteLine("Tank life: {0}", listOfTanks[0].life);
    }
}

