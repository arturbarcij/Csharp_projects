namespace DIKULecture;
     public class Speaker : Person
        {
            bool isInLecture = false;

            private Lecture Lecture;
            public Speaker (string speakerName, string speakerOccupation, int speakerAge)
             : base(speakerName, speakerOccupation, speakerAge)
            {
            }


             public bool getSpeakerStatus
        {
            get { return isInLecture; }
            set { isInLecture = value; }
        }
        
        
        
            public void Broadcast (Lecture testLecture) {
                
                if (isInLecture == false) {
                    
                    isInLecture = true;
                    Lecture = testLecture;
                }
                else
                {

                    Console.WriteLine("Speaker is already broadcasting.");
                    

                }
            }
            public void Speak (Lecture testLecture, string message) {   
                
                if (isInLecture == true) {
                    
                    Lecture.setInformation = message;
                    
                }
                
            }

            public void changeName (Lecture testLecture, string lectureName) {
                if (isInLecture == true) {
                    testLecture.setName = lectureName;
                    
                    
                }
            }
        }