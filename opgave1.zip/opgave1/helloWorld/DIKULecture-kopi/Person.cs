namespace DIKULecture 
{
        public class Person
    {
        private string name {get ; set; }
        private string occupation {get ; set; }
        private int age {get ; set; }

        public Person (string pName, string pOccupation, int pAge)
        {
            name = pName;
            occupation = pOccupation;
            age = pAge;

        }  

        public string getPName {
            get {return name;}
            }
        public string getPOccupation {
            get {return occupation;}
            }
        public int getPAge {
            get {return age;}
            }

    }
}
