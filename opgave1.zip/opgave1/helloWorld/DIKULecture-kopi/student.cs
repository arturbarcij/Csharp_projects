namespace DIKULecture;
 public class Student : Person
    {
        private bool isInLecture = false;
        private Lecture lecture;
        
        public Student (string studentName, string studentOccupation, int studentAge)
         : base(studentName, studentOccupation, studentAge)
        {

        }
    
        public bool getStudentStatus
        {
            get { return isInLecture; }
            set { isInLecture = value; }
        }

        

        public void Join (Lecture testLecture) {
            
        if (isInLecture == false)
        {
            testLecture.StudentNUM += 1;
            isInLecture = true;
            lecture = testLecture;
        }   
        else
        {
            Console.WriteLine("Student has already joined the lecture.");
        }    
        }

        public void Listen (Lecture testLecture, string Message) {
        
        if (isInLecture == false)
        {
            Console.WriteLine("Can not listen to the information.");
        }
        else
        {   
            Message = testLecture.getInformation;
            Console.WriteLine(Message);
        }
        }
        

        

        
    }