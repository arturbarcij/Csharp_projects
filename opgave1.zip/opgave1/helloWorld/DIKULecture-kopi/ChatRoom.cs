
using System;

    public class ChatRoom 
    {
        private string name {get ; set; }

        public ChatRoom (String theName)
        {
            name = theName;
        }
        
        public string getName {
            get {return name;}
            }

        public string setName {
            set {name = value;}
        }

    }
    
