﻿// See https://aka.ms/new-console-template for more information
namespace DIKULecture;

public class Program {
    public static void Main() {

        //LECTURES
        Lecture testLecture = new Lecture("MATEMATIK LECTURE");
        Lecture testLecture1 = new Lecture("PHYSICS LECTURE");

        //STUDENTS
        Student testStudent = new Student("Student0", "Math", 20);
        Student testStudent1 = new Student("Student1", "Math", 22);
        Student testStudent2 = new Student("Student2", "Physics", 24);
        Student testStudent3 = new Student("Student3", "Physics", 18);

        //SPEAKERS
        Speaker testSpeaker = new Speaker("Teacher", "math", 20);
        Speaker testSpeaker1 = new Speaker("Teacher1", "physics", 25);

        //START OF TESTING
        Console.WriteLine("----------------------------------------");
        Console.WriteLine("START TESTING DIKULecture:");

        //Testing Join() isInLecture == false
        testStudent.Join(testLecture);
        testStudent1.Join(testLecture);
        testStudent2.Join(testLecture1);
        testStudent3.Join(testLecture1);

        //Testing Join() isInLecture == true
        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Join() test: ");
        testStudent.Join(testLecture);
        testStudent1.Join(testLecture);
        testStudent2.Join(testLecture1);
        testStudent3.Join(testLecture1);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("HW Test: ");
        Console.WriteLine("Hello, World!");

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Getter and lecture instances tests: ");
        Console.WriteLine(testLecture);
        Console.WriteLine(testLecture1);
        Console.WriteLine("Math student num: {0}", testLecture.StudentNUM);
        Console.WriteLine("Physics student num: {0}", testLecture1.StudentNUM);
        Console.WriteLine("Lecture name: {0}: ", testLecture.getName);
        Console.WriteLine("Lecture name: {0}: ", testLecture1.getName);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Student status test: ");
        Console.WriteLine(testStudent.getStudentStatus);
        Console.WriteLine(testStudent1.getStudentStatus);
        Console.WriteLine(testStudent2.getStudentStatus);
        Console.WriteLine(testStudent3.getStudentStatus);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Broadcast() test: ");
        testSpeaker.Broadcast(testLecture);
        testSpeaker1.Broadcast(testLecture1);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Broadcast() test: isInLecture == true ");
        testSpeaker.Broadcast(testLecture);
        testSpeaker1.Broadcast(testLecture1);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Speak() test: ");
        testSpeaker.Speak(testLecture, "Welcome to Math class!");
        testSpeaker1.Speak(testLecture1, "Welcome to Physics class!");

        Console.WriteLine(testLecture.getInformation);
        Console.WriteLine(testLecture1.getInformation);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Listen() test: ");
        testStudent.Listen(testLecture, testLecture.getInformation);
        testStudent1.Listen(testLecture, testLecture.getInformation);
        testStudent2.Listen(testLecture1, testLecture.getInformation);
        testStudent3.Listen(testLecture1, testLecture.getInformation);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("changeName() test: ");
        testSpeaker.changeName(testLecture, "HACKATHON");
        testSpeaker.changeName(testLecture1, "BLOCKCHAIN");
        Console.WriteLine("New name of lecture is: {0}", testLecture.getName);
        Console.WriteLine("New name of lecture is: {0}", testLecture1.getName);

        //FUN WITH LISTS - EXTRA WORK
        List<Lecture> listOfLectures = new List<Lecture> ();
        listOfLectures.Add(testLecture);
        listOfLectures.Add(testLecture1);

        List<Student> listOfStudents = new List<Student> ();
        listOfStudents.Add(testStudent);
        listOfStudents.Add(testStudent1);
        listOfStudents.Add(testStudent2);
        listOfStudents.Add(testStudent3);

        List<Speaker> listOfSpeakers = new List<Speaker> ();
        listOfSpeakers.Add(testSpeaker);
        listOfSpeakers.Add(testSpeaker1);

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("FUN WITH LISTS");
        Console.WriteLine("----------------------------------------");

        Console.WriteLine("List of lectures: ");
        for (var l = 0; l < listOfStudents.Count; l++) {
            Console.WriteLine("Lecture {0}: {1}", l,  listOfStudents);
        }

        Console.WriteLine("----------------------------------------");
        Console.WriteLine("List of students: ");
        for (var i = 0; i < listOfStudents.Count; i++) {
            Console.WriteLine("Student {0}: {1}", i,  listOfStudents);
        }

        // Console.WriteLine("----------------------------------------");
        // Console.WriteLine("List of speakers: ");
        // for (var j = 0; j < listOfSpeakers.Count; j++) {
        //     var str = j;
        //     public override string ToString()
        //     {
        //         return base.ToString();
        //     }
        //     Console.WriteLine("Speaker {0}: {1}", j,  listOfSpeakers);
        // }

    }
}


