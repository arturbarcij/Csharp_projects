namespace DIKULecture;
public class Lecture : ChatRoom
{
        private int numOfStudentsOnline = 0;
        private string Information = "";
        public Lecture (string name) : base(name) {

        }

        public int StudentNUM
        {
            get { return numOfStudentsOnline; }
            set { numOfStudentsOnline = value; }
        }

        public string getInformation
        {
            get { return Information; }
        }

        public string setInformation 
        {
            set { Information = value;}
        }

        public override string ToString()  
        {  
            return getName + " " + StudentNUM;  
        } 
}       


